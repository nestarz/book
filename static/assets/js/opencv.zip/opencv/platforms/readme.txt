This folder contains toolchains and additional files that are needed for cross compilation.
For more information see introduction tutorials for target platform in documentation:
https://docs.opencv.org/master/df/d65/tutorial_table_of_content_introduction.html
